/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

/**
 *
 * @author Dell
 */
/**
 *
 * @author Dell
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import java.io.BufferedReader;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Datenbank {

    public List<PatientenInfo> list = new ArrayList<>();

public void readData(String filePath) {
    list.clear(); // Leere die Liste, um Datenkorruption zu vermeiden
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(";");
            if (values.length >= 8) { // Check if the array has enough elements
                String vorname = values[0];
                String nachname = values[1];
                String bluttyp = values[4];
                list.add(new PatientenInfo(vorname, nachname, Integer.parseInt(values[2]), Double.parseDouble(values[3]), bluttyp, values[5], values[6], values[7]));
            } else {
                System.out.println("Invalid data format: " + line);
            }
        }
        System.out.println("Daten erfolgreich eingelesen.");
    } catch (IOException | NumberFormatException e) {
        e.printStackTrace();
        System.out.println("Fehler beim Lesen der Daten: " + e.getMessage());
    }
}


    public List<PatientenInfo> getPatientData(String filePath) {
        readData(filePath); // Sicherstellen, dass die Daten aktualisiert sind
        return list;
    }

    public void addData(String filePath, String Vorname, String Nachname, int alter, double gewicht, String blutttype, String geschlecht, String adresse, String privatVersichert) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath, true))) {
            bw.append(Vorname + ";" + Nachname + ";" + alter + ";" + gewicht + ";" + blutttype + ";" + geschlecht + ";" + adresse + ";" + privatVersichert + "\n");
            System.out.println("Patientendaten wurden erfolgreich hinzugefügt");
            list.add(new PatientenInfo(Vorname, Nachname, alter, gewicht, blutttype, geschlecht, adresse, privatVersichert));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    public PatientenInfo findById(String Vorname, String Nachname) {
        for (PatientenInfo patient : list) {
            if (patient.getVorname().equals(Vorname) && patient.getNachname().equals(Nachname)) {
                return patient;
            }
        }
        System.out.println("Keine Daten mit diesem Namen gefunden: " + Vorname + " " + Nachname);
        return null;
    }

    public void updateData(String filePath, String beforupV, String beforeN, String Vorname, String Nachname, double gewicht, int alter, String bluttype, String geschlecht, String adresse, String privatVersichert) {
        PatientenInfo target = findById(beforupV, beforeN);
        if (target != null) {
            int index = list.indexOf(target);
            target.setVorname( Vorname);
            target.setNachname(Nachname);
            target.setGewicht(gewicht);
            target.setAlter(alter);
            target.setBluttype(bluttype);
            target.setGeschlecht(geschlecht);
            target.setAdresse(adresse);
            target.setPrivatVersichert(privatVersichert);
            list.set(index, target);
            //    writeData(filePath, target); // Write to file 
            System.out.println("Erfolgreiche Aktualisierung der Patientendaten von " + Vorname + " " + Nachname);
        } else {
            System.out.println("Patient mit dem Namen " + Vorname + " " + Nachname + " nicht gefunden. Aktualisierung fehlgeschlagen.");
        }
    }
    
    public void deleteData(String Vorname, String Nachname) {
        PatientenInfo target = findById(Vorname, Nachname);

        if (target != null) {
            list.remove(target);
            //    writeData(""); // Write to file after deletion
            System.out.println("Patient " + Vorname + " " + Nachname + " wurde erfolgreich gelöscht.");
        } else {
            System.out.println("Patient " + Vorname + " " + Nachname + " nicht gefunden. Löschung fehlgeschlagen.");
        }
    }

    public void writeDataFromList(String filePath) {
//        if (list.isEmpty()) {
//            readData(filePath);
//            System.out.println("List empty");
//        } else {
            try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
                for (PatientenInfo patient : list) {
                    System.out.println(patient.getVorname() + ";" + patient.getNachname() + ";" + patient.getAlter() + ";"
                            + patient.getGewicht() + ";" + patient.getBluttype() + ";" + patient.getGeschlecht() + ";" + patient.getAdresse() + ";"
                            + patient.isPrivatVersichert() + "\n");
                    writer.write(patient.getVorname() + ";" + patient.getNachname() + ";" + patient.getAlter() + ";"
                            + patient.getGewicht() + ";" + patient.getBluttype() + ";" + patient.getGeschlecht() + ";" + patient.getAdresse() + ";"
                            + patient.isPrivatVersichert() + "\n");
                    System.out.println("Datenbank wurde aktualisiert.");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                System.out.println(ex.getMessage());
            }
        
    }
    public void writeData(String filePath, JTable table) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            // Write the entire content of the table
            for (int i = 0; i < table.getRowCount(); i++) {
                String vorname = (String) table.getValueAt(i, 0);
                String nachname = (String) table.getValueAt(i, 1);
                int alter = (int) table.getValueAt(i, 2);
                double gewicht = (double) table.getValueAt(i, 3);
                String bluttype = (String) table.getValueAt(i, 4);
                String geschlecht = (String) table.getValueAt(i, 5);
                String adresse = (String) table.getValueAt(i, 6);
                String privatVersichert = (String) table.getValueAt(i, 7);

                writer.write(vorname + ";" + nachname + ";" + alter + ";"
                        + gewicht + ";" + bluttype + ";" + geschlecht + ";" + adresse + ";"
                        + privatVersichert + "\n");
            }

            System.out.println("Datenbank wurde aktualisiert.");
        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }

    // Rest of the methods like findById, updateData, deleteData...
    public List<PatientenInfo> suchePatientenNachNachname(String nachname, String filePath) {
        readData(filePath); // Aktualisieren der Daten vor der Suche
        List<PatientenInfo> foundPatients = new ArrayList<>();
        // Debugging-Ausgabe zum Überprüfen des übergebenen Nachnamens
        System.out.println("Gesuchter Nachname: " + nachname);

        for (PatientenInfo patient : list) {
            // Debugging-Ausgabe, um zu überprüfen, ob die Nachnamen übereinstimmen
            System.out.println("Vorhandener Nachname: " + patient.getNachname());
            if (patient.getNachname().equals(nachname)) {

                foundPatients.add(patient);
            }
        }
        System.out.println("Gefundene Patienten Anzahl: " + foundPatients.size()); // Debug-Ausgabe zur Überprüfung

        return foundPatients;
    }
}
