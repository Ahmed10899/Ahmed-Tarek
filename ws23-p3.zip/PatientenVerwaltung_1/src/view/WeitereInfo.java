/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author Dell
 */
import java.awt.Color;
import java.awt.Font;
import java.util.UUID;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class WeitereInfo extends JPanel{

	JLabel heading = new JLabel("Wer Sind Uns !");
	
	JLabel Nachname = new JLabel("Nachname: Tarek");
	JLabel Vorname = new JLabel("Vorname: Ahmed");
	JLabel Matrikelnummer = new JLabel("Matrikelnummer: 6047981");
        
        
        JLabel Nachname1 = new JLabel("Nachname: EDDIE BRYAN");
	JLabel Vorname1 = new JLabel("Vorname: TCHOUPE SAKAM");
	JLabel Matrikelnummer1 = new JLabel("Matrikelnummer: 6041785");
        
         JLabel Nachname2 = new JLabel("Nachname: Fotso Taboue");
	JLabel Vorname2 = new JLabel("Vorname: Moses Fritz");
	JLabel Matrikelnummer2 = new JLabel("Matrikelnummer: 6052222");

        
	JLabel Studiengang = new JLabel("Studiengang: Wirtschaftsinformatik");
	JLabel Hochschule = new JLabel("Hochschule: Jade Hochschule");

	
	public WeitereInfo()
	{
		
				
		heading.setFont(new Font("Roboto",Font.BOLD,28));
		heading.setBounds(300,0,400,100);
		
                Nachname.setFont(new Font("Roboto",Font.BOLD,16));
		Nachname.setBounds(100,100,400,100);
		

                
		Vorname.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Vorname.setBounds(100,130,400,100);
		
		
		Matrikelnummer.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Matrikelnummer.setBounds(100,160,400,100);
                
               
		
                Nachname1.setFont(new Font("Roboto",Font.BOLD,16));
		Nachname1.setBounds(100,280,400,100);
		

                
		Vorname1.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Vorname1.setBounds(100,310,400,100);
		
		
		Matrikelnummer1.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Matrikelnummer1.setBounds(100,340,400,100);
                
                
                Nachname2.setFont(new Font("Roboto",Font.BOLD,16));
		Nachname2.setBounds(100,420,400,100);
		

                
		Vorname2.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Vorname2.setBounds(100,450,400,100);
		
		
		Matrikelnummer2.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Matrikelnummer2.setBounds(100,480,400,100);
                
                
                
		
		Studiengang.setFont(new Font("Roboto",Font.BOLD,16));
		Studiengang.setBounds(100,550,400,100);

		Hochschule.setFont(new Font("Roboto",Font.BOLD,16));
		Hochschule.setBounds(100,580,400,100);

		


		

		setBackground(Color.WHITE);
		setLayout(null);
		add(heading);
		add(Nachname);
		add(Vorname);
		add(Matrikelnummer);
                add(Nachname1);
		add(Vorname1);
		add(Matrikelnummer1);
                add(Nachname2);
		add(Vorname2);
		add(Matrikelnummer2);
                
                
		add(Studiengang);
		add(Hochschule);
	

	

	}

   

   
}
    

