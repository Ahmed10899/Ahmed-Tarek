/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;



import Database.Datenbank;
import Database.PatientenInfo;
import PatientenVerwaltung.Patienten;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class PatientenSuche extends JPanel {

    JLabel nachnameLabel = new JLabel("Nachname");
    JTextField nachnameText = new JTextField();
    JButton sucheButton = new JButton("");
    Datenbank datenbank = new Datenbank();

    public PatientenSuche(Patienten pati) {
        
        setLayout(null);
        setBackground(Color.white);

        nachnameLabel.setBounds(280, 80, 70, 30);
        nachnameLabel.setFont(new Font("Arial", Font.BOLD, 12));
        nachnameText.setBounds(370, 75, 200, 40);

        sucheButton.setBounds(570, 75, 100, 40);
        sucheButton.setIcon(new ImageIcon(getClass().getResource("/such.gif")));

        sucheButton.addActionListener((ActionEvent e) -> {
            if (e.getSource() == sucheButton) {
                String nachname = nachnameText.getText().equals("Nachname") ? "" : nachnameText.getText();
                List<PatientenInfo> patientenListe = datenbank.suchePatientenNachNachname(nachname,pati.filePath);
                System.out.println("");
                patientenListeAnzeigen(patientenListe);
            }
        });

        add(nachnameLabel);
        add(nachnameText);
        add(sucheButton);
    }

    public void patientenListeAnzeigen(List<PatientenInfo> patientenListe) {
      //  removeAll(); // Entferne alle vorhandenen Komponenten aus dem Panel
      JPanel ergebnisPanel = new JPanel();
      ergebnisPanel.setLayout(new BoxLayout(ergebnisPanel, BoxLayout.PAGE_AXIS));
      JScrollPane ergebnisListe = new JScrollPane(ergebnisPanel);
            JLabel nameLabel = new JLabel();
            JLabel ageLabel = new JLabel();
            JLabel weightLabel = new JLabel();
            JLabel genderLabel = new JLabel();
            JLabel addressLabel = new JLabel();
            JLabel PrivateinsuranceLabel = new JLabel();

            // Füge die Labels zum ergebnisPanel hinzu
            ergebnisPanel.add(nameLabel);
            ergebnisPanel.add(ageLabel);
            ergebnisPanel.add(weightLabel);
            ergebnisPanel.add(genderLabel);
            ergebnisPanel.add(addressLabel);
            ergebnisPanel.add(PrivateinsuranceLabel);

            // Füge Raum zwischen den Ergebnissen hinzu
            ergebnisPanel.add(Box.createRigidArea(new Dimension(200, 50)));
            ergebnisListe.setBounds(270, 200, 400, 400);
            add(ergebnisListe);
            
            
        if (!patientenListe.isEmpty()) {
           for (PatientenInfo patient : patientenListe) {
            nameLabel.setText("Name: " + patient.getVorname() + " " + patient.getNachname());
            ageLabel.setText("Alter: " + patient.getAlter());
            weightLabel.setText("Gewicht: " + patient.getGewicht());
            genderLabel.setText("Geschlecht: " + patient.getGeschlecht());
            addressLabel.setText("Adresse: " + patient.getAdresse());
            PrivateinsuranceLabel.setText("Privat Versichert : " + patient.getPrivatVersichert());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Keine Patienten wurden gefunden");
        }
    }
}