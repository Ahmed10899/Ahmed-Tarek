// Paket für die Patientenverwaltung
package PatientenVerwaltung;

// Importieren von erforderlichen Java-Klassen und Swing-Komponenten
import Database.Datenbank;
import Database.PatientenInfo;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Patienten extends JPanel {

    public String filePath = "patientendaten.csv";
    DefaultTableModel tableModel;
    JTable table;
    Datenbank datenbank;
    SpinnerModel alterModel = new SpinnerNumberModel(0, 0, 150, 1);
    SpinnerModel gewichtModel = new SpinnerNumberModel(0.0, 0.0, 500.0, 0.1);
    JLabel NachnameLabel = new JLabel("Nachname:");
    JLabel VornameLabel = new JLabel("Vorname:");
    JLabel alterLabel = new JLabel("Alter:");
    JLabel gewichtLabel = new JLabel("Gewicht:");
    JLabel bluttypLabel = new JLabel("Bluttyp:");
    JLabel geschlechtLabel = new JLabel("GeschlechtAuswahl:");
    JLabel adresseLabel = new JLabel("Adresse:");
    JLabel privatVersichertLabel = new JLabel("Privat Versichert?");

    JPanel panelNeuerPatient = new JPanel();
    JLabel labelPatientenListe = new JLabel();
    public JTextField NachnameTextField = new JTextField();
    public JTextField VornameTextField = new JTextField();
    public JSpinner alterSpinner = new JSpinner(alterModel);
    public JSpinner gewichtSpinner = new JSpinner(gewichtModel);
    public JTextField bluttypTextField = new JTextField();
    public JComboBox<String> geschlechtComboBox = new JComboBox<>(new String[]{"Männlich", "Weiblich"});
    public JTextField adresseTextField = new JTextField();
    public JCheckBox privatVersichertCheckBox = new JCheckBox();

    JLabel bildLabel = new JLabel();
    JLabel textLabel = new JLabel("Bild Hochladen");

    JButton hinzufuegen = new JButton("Hinzufügen");
    JButton loeschen = new JButton("Löschen");
    JButton aendern = new JButton("Ändern");
    JButton speichern = new JButton("Speichern");
    JButton speichernProgrammButton = new JButton("Programm speichern");
    JButton shiftBtn = new JButton("<");
//    public String Nachname;
//    public String Vorname;
//    public double gewicht;
//    public boolean privatVersichert;
//    public String adresse;
//    public int alter;
//    public String geschlecht;

    public Patienten() {

        setLayout(null);
        setBackground(Color.cyan);
        datenbank = new Datenbank();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Vorname");
        tableModel.addColumn("Nachname");
        tableModel.addColumn("Alter");
        tableModel.addColumn("Gewicht");
        tableModel.addColumn("Bluttyp");
        tableModel.addColumn("GeschlechtAuswahl");
        tableModel.addColumn("Adresse");
        tableModel.addColumn("Privat Versichert");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(450, 250, 1000, 700);
        add(scrollPane);

         NachnameLabel.setBounds(30, 100, 150, 30);
        NachnameTextField.setBounds(100, 100, 200, 30);
        VornameLabel.setBounds(40, 160, 150, 30);
        VornameTextField.setBounds(100, 160, 200, 30);
        alterLabel.setBounds(40, 220, 150, 30);
        alterSpinner.setBounds(100, 220, 200, 30);
        gewichtLabel.setBounds(40, 280, 150, 30);
        gewichtSpinner.setBounds(100, 280, 200, 30);
        bluttypLabel.setBounds(40, 340, 150, 30);
        bluttypTextField.setBounds(100, 340, 200, 30);
        geschlechtLabel.setBounds(40, 400, 150, 30);
        geschlechtComboBox.setBounds(170, 400, 90, 30);
        adresseLabel.setBounds(40, 460, 150, 30);
        adresseTextField.setBounds(100, 460, 200, 30);
        privatVersichertLabel.setBounds(40, 520, 150, 30);
        privatVersichertCheckBox.setBounds(200, 520, 30, 30);

        setLayout(new BorderLayout());

        // Annahme: Du hast bereits andere Komponenten erstellt, z. B. scrollPane
        // ...
        // Erstelle das Label für die Patientenliste
        // Erstelle das Panel für den neuen Patienten
        panelNeuerPatient.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); // Setze das Layout
        panelNeuerPatient.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Neuer Patient", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Print", 1, 18)));
        panelNeuerPatient.setOpaque(false);

        // Füge die Komponenten in das Hauptpanel hinzu
        add(labelPatientenListe, BorderLayout.NORTH);
        add(panelNeuerPatient, BorderLayout.CENTER);

        hinzufuegen.setBounds(20, 700, 140, 30);
        hinzufuegen.setFont(new java.awt.Font("Segoe Print", 1, 12));
        hinzufuegen.setIcon(new ImageIcon(getClass().getResource("/add.gif")));

        loeschen.setBounds(200, 700, 140, 30);
        loeschen.setFont(new java.awt.Font("Segoe Print", 1, 12));
        loeschen.setIcon(new ImageIcon(getClass().getResource("/bin.png")));

        aendern.setBounds(20, 800, 140, 30);
        aendern.setFont(new java.awt.Font("Segoe Print", 1, 12));
        aendern.setIcon(new ImageIcon(getClass().getResource("/eraser.png")));

        speichern.setBounds(200, 800, 140, 30);
        speichern.setFont(new java.awt.Font("Segoe Print", 1, 12));
        speichern.setIcon(new ImageIcon(getClass().getResource("/speichern.png")));

        shiftBtn.setBounds(380, 290, 40, 25);
        shiftBtn.setFont(new java.awt.Font("Segoe Print", 1, 12));
        speichernProgrammButton.setBounds(80, 900, 200, 30);
        speichernProgrammButton.setFont(new java.awt.Font("Segoe Print", 1, 12));
        speichernProgrammButton.setIcon(new ImageIcon(getClass().getResource("/save.gif")));

        textLabel.setBounds(30, 100, 150, 30);// Passe die Position und Größe nach Bedarf an
        panelNeuerPatient.add(textLabel);

        bildLabel.setBounds(400, 500, 100, 50); // Setze die Größe für das Bildsymbol
        bildLabel.setIcon(new ImageIcon(getClass().getResource("/upload.png")));
        panelNeuerPatient.add(bildLabel);

        //stay infor
        List<PatientenInfo> patientenList = datenbank.getPatientData(filePath);
        for (PatientenInfo patient : patientenList) {
            Object[] rowData = {patient.getVorname(), patient.getNachname(), patient.getAlter(), patient.getGewicht(), patient.getBluttype(), patient.getGeschlecht(), patient.getAdresse(), patient.getPrivatVersichert()};
            //  tableModel.setRowCount(0);
            tableModel.addRow(rowData);
        }
        bildLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileFilter(new FileNameExtensionFilter("Bilder", "jpg", "jpeg", "png", "gif"));
                int option = fileChooser.showOpenDialog(null);

                if (option == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    if (selectedFile != null) {
                        try {
                            ImageIcon imageIcon = new ImageIcon(selectedFile.getAbsolutePath());
                            Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                            imageIcon = new ImageIcon(image);
                            bildLabel.setIcon(imageIcon);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Fehler beim Laden des Bildes.", "Fehler", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });

        shiftBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String Vorname = (String) tableModel.getValueAt(selectedRow, 0);
                    String Nachname = (String) tableModel.getValueAt(selectedRow, 1);
                    int alter = (int) tableModel.getValueAt(selectedRow, 2);
                    double gewicht = (double) tableModel.getValueAt(selectedRow, 3);
                    String bluttyp = (String) tableModel.getValueAt(selectedRow, 4);
                    String geschlecht = (String) tableModel.getValueAt(selectedRow, 5);
                    String adresse = (String) tableModel.getValueAt(selectedRow, 6);
                    String privatVersichert = (String) tableModel.getValueAt(selectedRow, 7);

                    VornameTextField.setText(Vorname);
                    NachnameTextField.setText(Nachname);
                    alterSpinner.setValue(alter);
                    gewichtSpinner.setValue(gewicht);
                    bluttypTextField.setText(bluttyp);
                    geschlechtComboBox.setSelectedItem(geschlecht);
                    adresseTextField.setText(adresse);
                    privatVersichertCheckBox.setSelected(privatVersichert.equals("Ja"));
                }
            }
        });

        speichernProgrammButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("CSV-Datei auswählen");
                fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Dateien", "csv"));

                int userSelection = fileChooser.showOpenDialog(null);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    if (selectedFile != null) {
                        filePath = selectedFile.getAbsolutePath();
                        List<PatientenInfo> patientenList = datenbank.getPatientData(filePath);
                        for (PatientenInfo patient : patientenList) {
                            Object[] rowData = {patient.getVorname(), patient.getNachname(), patient.getAlter(), patient.getGewicht(), patient.getBluttype(), patient.getGeschlecht(), patient.getAdresse(), patient.getPrivatVersichert()};
                            //  tableModel.setRowCount(0);
                            tableModel.addRow(rowData);
                        }
                    }

                }
            }
        });

        hinzufuegen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                String privatVersichert = privatVersichertCheckBox.isSelected() ? "Ja" : "Nein";

                int option = JOptionPane.showConfirmDialog(null, "Möchten Sie den Patienten hinzufügen?", "Hinzufügen", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    int alterx = ((Number) alterSpinner.getValue()).intValue();
                    double gewichtx = ((Number) gewichtSpinner.getValue()).doubleValue();
                    Object[] rowData = {VornameTextField.getText(), NachnameTextField.getText(), alterx, gewichtx, bluttypTextField.getText(), geschlechtComboBox.getSelectedItem(), adresseTextField.getText(), privatVersichert};

                    datenbank.addData(filePath, VornameTextField.getText(), NachnameTextField.getText(), alterx, gewichtx, bluttypTextField.getText(), geschlechtComboBox.getSelectedItem().toString(), adresseTextField.getText(), privatVersichert);
                    tableModel.addRow(rowData);
                    JOptionPane.showMessageDialog(null, "Patient wurde hinzugefügt!", "Hinzufügen", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Der Vorgang wurde abgebrochen.", "Abgebrochen", JOptionPane.WARNING_MESSAGE);
                }

                VornameTextField.setText("");
                NachnameTextField.setText("");
                alterSpinner.setValue(0);
                gewichtSpinner.setValue(0);
                bluttypTextField.setText("");
                adresseTextField.setText("");
                geschlechtComboBox.setSelectedIndex(0);
                privatVersichertCheckBox.setSelected(false);
            }
        });

        loeschen.addActionListener((ActionEvent event) -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int confirm = JOptionPane.showConfirmDialog(null, "Sind Sie sicher, dass Sie den Patienten löschen möchten?", "Löschen", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                   String vorname = table.getValueAt(selectedRow, 0).toString();
                   String nachname = table.getValueAt(selectedRow, 1).toString();
                    datenbank.deleteData(vorname, nachname);
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Patient wurde gelöscht!", "Löschen", JOptionPane.INFORMATION_MESSAGE);
                } else if (confirm == JOptionPane.NO_OPTION) {
                    JOptionPane.showMessageDialog(null, "Der Patient wurde nicht gelöscht.", "Löschen abgebrochen", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Bitte wählen Sie einen Patienten zum Löschen aus!", "Löschen", JOptionPane.WARNING_MESSAGE);
            }
        });
        aendern.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int option = JOptionPane.showConfirmDialog(null, "Möchten Sie die Patientendaten ändern?", "Ändern", JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                        //Here update
                        String beforeupVorn =  tableModel.getValueAt(selectedRow, 0).toString();
                        String beforeupNach =  tableModel.getValueAt(selectedRow, 1).toString();
                        tableModel.setValueAt(VornameTextField.getText(), selectedRow, 0);
                        tableModel.setValueAt(NachnameTextField.getText(), selectedRow, 1);
                        tableModel.setValueAt(alterSpinner.getValue(), selectedRow, 2);
                        tableModel.setValueAt(gewichtSpinner.getValue(), selectedRow, 3);
                        tableModel.setValueAt(bluttypTextField.getText(), selectedRow, 4);
                        tableModel.setValueAt(geschlechtComboBox.getSelectedItem(), selectedRow, 5);
                        tableModel.setValueAt(adresseTextField.getText(), selectedRow, 6);
                        tableModel.setValueAt(privatVersichertCheckBox.isSelected() ? "Ja" : "Nein", selectedRow, 7);

                        int alterx = ((Number) alterSpinner.getValue()).intValue();
                        double gewichtx = ((Number) gewichtSpinner.getValue()).doubleValue();
                        datenbank.updateData(filePath,beforeupVorn,beforeupNach, table.getValueAt(selectedRow, 0).toString(), table.getValueAt(selectedRow, 1).toString(), gewichtx, alterx, bluttypTextField.getText(), geschlechtComboBox.getSelectedItem().toString(), adresseTextField.getText(), privatVersichertCheckBox.isSelected() ? "Ja" : "Nein");
                        JOptionPane.showMessageDialog(null, "Patientendaten wurden geladen. Bitte bearbeiten Sie und klicken Sie auf 'Änderung speichern'.", "Ändern", JOptionPane.INFORMATION_MESSAGE);
                        VornameTextField.setText("");
                        NachnameTextField.setText("");
                        alterSpinner.setValue(0);
                        gewichtSpinner.setValue(0);
                        bluttypTextField.setText("");
                        geschlechtComboBox.setSelectedIndex(0);
                        adresseTextField.setText("");
                        privatVersichertCheckBox.setSelected(false);
                    } else if (option == JOptionPane.NO_OPTION) {
                        JOptionPane.showMessageDialog(null, "Der Patient wurde nicht geändert.", "Ändern abgebrochen", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        speichern.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (table.getRowCount() != -1) {
                    int option = JOptionPane.showConfirmDialog(null, "Möchten Sie die Änderungen speichern?", "Änderung speichern", JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        // StringBuilder csvData = new StringBuilder();
                        //  datenbank.writeData(filePath, table);
                        datenbank.writeDataFromList(filePath);
                        JOptionPane.showMessageDialog(null, "Patientendaten wurden aktualisiert!", "Änderung speichern", JOptionPane.INFORMATION_MESSAGE);
                    } else if (option == JOptionPane.NO_OPTION) {
                        JOptionPane.showMessageDialog(null, "Aktualisierung abgebrochen.", "Aktualisierung abgebrochen", JOptionPane.INFORMATION_MESSAGE);
                    }

                }
            }
        }
        );

        add(loeschen);

        add(aendern);

        add(speichern);

        add(hinzufuegen);

        add(VornameTextField);

        add(NachnameTextField);

        add(alterSpinner);

        add(gewichtSpinner);

        add(adresseTextField);

        add(bluttypTextField);

        add(geschlechtComboBox);

        add(privatVersichertCheckBox);

        add(VornameLabel);

        add(NachnameLabel);

        add(bluttypLabel);

        add(adresseLabel);

        add(geschlechtLabel);

        add(alterLabel);

        add(gewichtLabel);

        add(privatVersichertLabel);

        add(speichernProgrammButton);

        add(shiftBtn);

        add(labelPatientenListe);

        add(panelNeuerPatient);

    }

}
