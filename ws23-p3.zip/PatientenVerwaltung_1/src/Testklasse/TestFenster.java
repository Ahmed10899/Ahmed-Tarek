package Testklasse;

import javax.swing.JFrame;
import view.Fenster;


public class TestFenster extends JFrame{
    public static void main(String[] args) {
        // Setzen des Look and Feels auf Nimbus (für eine ansprechende Benutzeroberfläche)        
        // Erstellen und Anzeigen des Hauptfensters
        Fenster f = new Fenster();
        f.setVisible(true);
    }
}
